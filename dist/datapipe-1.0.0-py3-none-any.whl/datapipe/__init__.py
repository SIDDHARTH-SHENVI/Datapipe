def main():
    from .cli import cli
    cli()